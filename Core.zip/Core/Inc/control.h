/*
 * control.h
 *
 *  Created on: Dec 6, 2024
 *      Author: HALAB_G
 */

#ifndef INC_CONTROL_H_
#define INC_CONTROL_H_

void Control(void);

#endif /* INC_CONTROL_H_ */
