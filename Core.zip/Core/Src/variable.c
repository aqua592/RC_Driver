/*
 * variable.c
 *
 *  Created on: Dec 6, 2024
 *      Author: HALAB_G
 */

int Align_done = 0;


int Theta_mode = 0;
///Extended EMF sensorless
float W_SPD_PLL = 0., Kp_SPD_PLL = 0., Ki_SPD_PLL = 0., integ_Thetar_PLL = 0.;

float Van = 0., Vbn = 0., Vcn = 0.;
float Vdss_ref_set = 0., Vqss_ref_set = 0., Vdse_ref_set = 0., Vqse_ref_set = 0.;


